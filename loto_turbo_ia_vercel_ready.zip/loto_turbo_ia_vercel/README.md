# Loto Turbo IA - versão pronta para Vercel

Esta é a versão mais simples para publicar como PWA instalável no iPhone e Android.

## Como publicar na Vercel pelo celular ou computador

1. Entre em https://vercel.com e crie uma conta.
2. Clique em Add New > Project.
3. Envie este projeto para o GitHub ou use a opção de importar o ZIP se disponível na sua conta.
4. Na configuração do projeto, deixe:
   - Framework Preset: Vite
   - Build Command: npm run build
   - Output Directory: dist
   - Install Command: npm install
5. Clique em Deploy.
6. Abra o link gerado no Safari do iPhone.
7. Toque em Compartilhar > Adicionar à Tela de Início.

## O que já vem pronto

- PWA instalável.
- Manifesto e ícones.
- Service Worker.
- Interface mobile.
- Conferidor de jogo.
- Gerador inteligente.
- API serverless em `/api/megasena/latest` para buscar o último resultado.

## Rodar localmente

```bash
npm install
npm run dev
```

Depois abra o endereço mostrado no terminal.

## Observação sobre notificações

O botão de notificação local já está na tela. Para notificações automáticas vindas do servidor quando sair resultado novo, conecte OneSignal, Firebase Cloud Messaging ou Web Push com VAPID em uma próxima versão.
