# Loto Turbo IA - PWA instalável

Esta versão roda como site e pode ser instalada na tela inicial do iPhone/Android.

## Rodar localmente
```bash
cd pwa
npm install
npm run dev
```

## Conectar ao backend
Por padrão, o PWA tenta acessar:
```bash
http://localhost:3333/api/megasena/latest
```

Para produção, crie um arquivo `.env` dentro da pasta `pwa`:
```bash
VITE_API_URL=https://seu-backend.com/api/megasena/latest
```

## Publicar na Vercel
1. Suba a pasta do projeto no GitHub.
2. Entre em https://vercel.com.
3. Importe o repositório.
4. Configure o diretório do projeto como `pwa`.
5. Build command: `npm run build`.
6. Output directory: `dist`.

## Instalar no iPhone
1. Abra o link publicado no Safari.
2. Toque em Compartilhar.
3. Toque em Adicionar à Tela de Início.
4. Abra pelo ícone criado.
5. Toque em Ativar notificações.

## Observação sobre notificações
Notificações web no iPhone exigem HTTPS e que o usuário adicione o PWA à Tela de Início. Para push real vindo do servidor, conecte Firebase Cloud Messaging, OneSignal ou Web Push com VAPID no backend.
